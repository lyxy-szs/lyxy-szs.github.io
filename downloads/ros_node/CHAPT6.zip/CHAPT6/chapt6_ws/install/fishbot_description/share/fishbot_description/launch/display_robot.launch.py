#display_robot.launch.py

#!/usr/bin/env python3
import launch
import launch_ros
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    # 获取默认的urdf路径
    urdf_package_path = get_package_share_directory('fishbot_description')
    default_urdf_path = os.path.join(urdf_package_path, 'urdf', 'first_robot.urdf')
    default_rviz_config_path = os.path.join(urdf_package_path, 'config', 'display_robot_model.rviz')
    # 1. 修复：launch.action → launch.actions（加s）
    action_declear_arg_mode_path = launch.actions.DeclareLaunchArgument(
        name='model',
        default_value=str(default_urdf_path),
        description='加载的模型文件路径'
    )

    # 2. 修复：换行语法错误（加\或调整括号）
    substitutions_command_result = launch.substitutions.Command(
        ['xacro ', launch.substitutions.LaunchConfiguration('model')]
    )
    # 构建机器人描述参数值
    robot_state_publisher_value = launch_ros.parameter_descriptions.ParameterValue(
        substitutions_command_result,
        value_type=str
    )

    # 3. 修复：参数名 robot_state_publisher → robot_description
    action_robot_state_publisher = launch_ros.actions.Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        parameters=[{'robot_description': robot_state_publisher_value}]
        # parameters is professional for point == ros2 run rviz2 rviz2 --ros-args -p xx:=xxxvalue
    )

    action_joint_state_publisher = launch_ros.actions.Node(
        package='joint_state_publisher',
        executable='joint_state_publisher',
    )

    action_rviz_node = launch_ros.actions.Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', default_rviz_config_path]
      # add function after rviz == ros2 run rviz2 rviz2 -d /home/noi/fishros/CHAPT6/chapt6_ws/src/fishbot_description/config/display_robot_model.rviz
    )

    return launch.LaunchDescription([
        action_declear_arg_mode_path,
        action_robot_state_publisher,
        action_joint_state_publisher,
        action_rviz_node,
    ])